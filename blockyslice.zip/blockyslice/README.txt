This is a simple text file
